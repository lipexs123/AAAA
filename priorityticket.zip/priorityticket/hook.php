<?php

/**
 * Install hook
 *
 * @return boolean
 */
function plugin_priorityticket_install()
{
   global $DB;

   //instanciate migration with version
   $migration = new Migration(100);

   if (!$DB->tableExists('glpi_plugin_priorityticket_config')) {
      //table creation query
      $query = "CREATE TABLE `glpi_plugin_priorityticket_config` (
                  `id` INT(11) auto_increment NOT NULL,
                  `status` INT(11) NOT NULL,
                  PRIMARY KEY  (`id`)
               ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
      $DB->queryOrDie($query, $DB->error());

      $query = "INSERT INTO `glpi_plugin_priorityticket_config` 
         (`id`,`status`)
         VALUES (1,4);";

      $DB->query($query) or die("error populate glpi_plugin_priorityticket_config " . $DB->error());

      $query = "INSERT INTO glpi_requesttypes (name,is_helpdesk_default,is_followup_default,is_mail_default,is_mailfollowup_default,is_active,is_ticketheader,is_itilfollowup,comment)
      VALUES ('Reabertos',0,0,0,0,1,1,1,'');";
      $DB->queryOrDie($query, $DB->error());
   }

   $migration->executeMigration();

   return true;
}

/**
 * Uninstall hook
 *
 * @return boolean
 */
function plugin_priorityticket_uninstall()
{

   global $DB;

   //instanciate migration with version
   $migration = new Migration(100);

   if ($DB->tableExists('glpi_plugin_priorityticket_config')) {
      $query = "DROP TABLE glpi_plugin_priorityticket_config";
      $DB->queryOrDie($query, $DB->error());

      $query = "DELETE FROM glpi_requesttypes
      WHERE name = 'Reabertos';";
      $DB->queryOrDie($query, $DB->error());
   }

   return true;
}

function plugin_priorityticket_reopen($item)
{
   global $DB;
   $checkSolve = $item->updates;

   if(in_array("status", $checkSolve) && 
      in_array("solvedate", $checkSolve) && 
      in_array("date_mod", $checkSolve) && 
      in_array("waiting_duration", $checkSolve) && 
      in_array("begin_waiting_date", $checkSolve) && 
      in_array("solve_delay_stat", $checkSolve)) {
         $query = "select * from glpi_itilsolutions where items_id = ". $item->fields['id'];
         $return = $DB->query($query) or die("error" . $DB->error());
         $data = $DB->fetchArray($return);

         if ($data['status'] == 4) {
            $query = "select * from glpi_requesttypes where name = 'Reabertos'";
            $return = $DB->query($query) or die("error" . $DB->error());
            $categorieId = $DB->fetchArray($return)['id'];

            $query = "select * from glpi_plugin_priorityticket_config where id = 1";
            $return = $DB->query($query) or die("error" . $DB->error());
            $status = $DB->fetchArray($return)['status'];

            $query = "UPDATE glpi_tickets
            SET requesttypes_id=".$categorieId.",
            status=".$status."
            WHERE id=".$item->fields['id'].";";
            $DB->query($query, $DB->error());

            $query = "DELETE from glpi_tickets_users 
            where tickets_id = ".$item->fields['id']." and type = 2;";
            $DB->queryOrDie($query, $DB->error());
         }
   }
}