<?php
include ("../../../inc/includes.php");

Session::checkRight("config", UPDATE);

// To be available when plugin in not activated
Plugin::load('example');

Html::header("TITRE", $_SERVER['PHP_SELF'], "config", "plugins");

global $CFG_GLPI;

$query = " select * from glpi_plugin_priorityticket_config";

$return = $DB->query($query) or die("error" . $DB->error());
$data = $DB->fetchArray($return);

if (isset($_GET['status'])) {
    $status = $_GET['status'];

    $query = "UPDATE `glpi_plugin_priorityticket_config` 
    SET status =". $status ." where id=1";

    $DB->query($query) or die("Erro ao salvar o status" . $DB->error());

    // $data['status'] = $status;
    Session::addMessageAfterRedirect("Status definido com sucesso", true, 'SUCCESS', false);
    Html::redirect($CFG_GLPI["root_doc"] . "/plugins/priorityticket/front/config.php");  
}
?>

<div class="ui-tabs-panel ui-corner-bottom ui-widget-content">
    <form action="config.php" method="get" name="form_ticket" enctype="multipart/form-data">
        <div class="spaced">
            <table class="tab_cadre_fixe">
                <tbody>
                    <tr class="headerRow responsive_hidden">
                        <th colspan="6" class="align-center">Para qual status o chamado deve ser movido após negado?</th>
                    </tr>
                    <tr>
                        <td class="align-center">
                            <select name="status" id="status">
                                <option value="1" <?php if($data['status'] == 1){ echo 'selected';} ?>>Novo</option>
                                <option value="2" <?php if($data['status'] == 2){ echo 'selected';} ?>>Em atendimento (atribuído)</option>
                                <option value="3" <?php if($data['status'] == 3){ echo 'selected';} ?>>Em atendimento (planejado)</option>
                                <option value="4" <?php if($data['status'] == 4){ echo 'selected';} ?>>Pendente</option>
                                <option value="5" <?php if($data['status'] == 5){ echo 'selected';} ?>>Solucionado</option>
                                <option value="6" <?php if($data['status'] == 6){ echo 'selected';} ?>>Fechado</option>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="align-center">
            <button class='vsubmit' type="submit">Save</button>
        </div>
    </form>
</div>

<?php
Html::footer();