const profileId = document.getElementById("profileIdJs").value;
const rootDocJs = document.getElementById("rootDocJs").value;

if (profileId == 31) {
    setTimeout(function() {
        forms = document.querySelectorAll('.nav-item[title="Assistência"] .dropdown-menu .dropdown-menu-columns .dropdown-menu-column .dropdown-item[href="'+rootDocJs+'/front/ticket.form.php"]');
        forms.forEach((element) => element.remove());
    
        menu = document.querySelectorAll('.nav-item .btn.btn-icon.btn-sm.btn-secondary[href="'+rootDocJs+'/front/ticket.form.php"]');
        menu.forEach((element) => element.remove());
      }, 2000)
}
