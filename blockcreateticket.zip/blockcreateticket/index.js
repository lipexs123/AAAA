// const profileId = document.getElementById("profileIdJs").textContent;

// if (profileId == 31) {
    // setTimeout(function() {
        forms = document.querySelectorAll('.nav-item[title="Assistência"] .dropdown-menu .dropdown-menu-columns .dropdown-menu-column .dropdown-item[href="/front/ticket.form.php"]');
        forms.forEach((element) => element.classList.add("removeCreateTicket"));
    
        menu = document.querySelectorAll('.nav-item .btn.btn-icon.btn-sm.btn-secondary[href="/front/ticket.form.php"]');
        menu.forEach((element) => element.classList.add("removeCreateTicket"));
      // }, 2000)
// }
