<?php

/**
 * Install hook
 *
 * @return boolean
 */
function plugin_blockcreateticket_install()
{

   return true;
}

/**
 * Uninstall hook
 *
 * @return boolean
 */
function plugin_blockcreateticket_uninstall()
{
   return true;
}

function plugin_trackcorreios_update_track()
{
  global $DB;
  global $CFG_GLPI;
  
  if (array_key_exists('glpiactiveprofile', $_SESSION)) {
    echo "<input type='text' style='display:none' id='profileIdJs' value='".$_SESSION['glpiactiveprofile']['id']."'>";
    echo "<input type='text' style='display:none' id='rootDocJs' value='".$CFG_GLPI["root_doc"]."'>";
  }
}