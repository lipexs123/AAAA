<?php

/**
 * Install hook
 *
 * @return boolean
 */
function plugin_blockcreateticket_install()
{

   return true;
}

/**
 * Uninstall hook
 *
 * @return boolean
 */
function plugin_blockcreateticket_uninstall()
{
   return true;
}

function plugin_trackcorreios_update_track()
{
  global $DB;
  global $CFG_GLPI;
  
  if (array_key_exists('glpiactiveprofile', $_SESSION)) {
    if ($_SESSION['glpiactiveprofile']['id'] == 2) {
      $value = '.dropdown-item[href="'.$CFG_GLPI["root_doc"].'/front/ticket.form.php"]';
      $secondValue = '.nav-item .btn.btn-icon.btn-sm.btn-secondary[href="'.$CFG_GLPI["root_doc"].'/front/ticket.form.php"]';

      echo "<script>
      setTimeout(function() {
        forms = document.querySelectorAll('$value');
        forms.forEach((element) => element.remove());

        menu = document.querySelectorAll('$secondValue');
        menu.forEach((element) => element.remove());
      }, 3000);
      </script>";
    }
  }
}