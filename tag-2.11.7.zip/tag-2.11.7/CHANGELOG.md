Changelogs for Tag plugin
=========================

GLPI Tag 2.6.0
-------------------------------

+ Show tags on Kanban view.

GLPI Tag 2.5.0
-------------------------------

* Add right management - Please review plugin rights after update.

GLPI Tag 0.90-1.1 (2016)
-------------------------------

* First version only for 0.90 : this version check version 0.90 on install
* Important fix for datainjection : can use Tag and datainjection in the same GLPI
* Add support of datainjection : Can import Tags, with the fields : name, color in format #hex (#aaaaaa)
* Filter tags by type menu -> filter tags by itemtype(s)
* Few fixes foe 0.90
